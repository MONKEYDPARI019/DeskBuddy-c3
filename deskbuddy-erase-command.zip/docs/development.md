# Development

How the project is put together, how to build and test it, and how to cut a release.

## Repository layout

```
DeskBuddy-C3/
├─ firmware/                    PlatformIO project
│  ├─ platformio.ini            envs: c3 (USB), c3-battery, ota
│  ├─ partitions.csv            4 MB: nvs, otadata, app0/app1 (1.875 MB each), spiffs, coredump
│  ├─ src/                      firmware sources
│  │  └─ logic/                 pure C++ (no Arduino), unit-tested on a PC
│  ├─ docs/PROTOCOL.md          app ↔ board messages
│  └─ test/host/                host unit tests (g++)
├─ app/                         Android app (Kotlin, Jetpack Compose)
├─ tool/                        deskbuddy-cli (Python)
│  ├─ pyproject.toml
│  ├─ src/deskbuddy/            cli.py, ui.py, installer.py, flasher.py, firmware.py, builder.py,
│  │                            github.py, serial_io.py, monitor.py, ports.py, doctor.py, …
│  └─ tests/                    pytest suite
├─ scripts/merge_firmware.py    release builds: merged image + SHA256SUMS + manifest.json
└─ .github/workflows/           ci.yml, release.yml
```

## Firmware

### Building

Pick whichever you like:

- **Command line, no setup:** from the repo root, run `deskbuddy build --env usb`, or `deskbuddy flash --local` to build and flash in one go. This uses the tool's own private PlatformIO.
- **VS Code + PlatformIO:**
  1. Open the **`firmware`** folder itself, not the repo root.
  2. Pick the environment in the status bar (`env:c3` or `env:c3-battery`).
  3. Click **Upload**, then use PlatformIO's **Serial Monitor** (plug icon).
- **PlatformIO CLI:** `cd firmware`, then `pio run -e c3 -t upload` and `pio device monitor`.

**Over WiFi (OTA):** with the board in WiFi mode on the same network, run `cd firmware` then `pio run -e ota -t upload`. It uploads to `deskbuddy-c3.local`; the board shows a progress bar while it updates.

### Architecture

One main loop does everything, in a fixed order: serial commands → radio → incoming app messages → buttons → app logic → sound → LEDs → display. Only the Bluetooth stack runs in its own task, and its callbacks just put complete JSON lines into a queue (`link.cpp`). Nothing else is shared, so there are no locks and no race conditions.

| Module | Job |
|---|---|
| `main.cpp` | `setup()` and the main loop. Boot sequence, and the both-buttons radio switch. |
| `config.h` | Pins, timings, `FW_VERSION`, `FEATURE_BATTERY` |
| `settings.*` | Settings in flash (NVS namespace `dbc3`), written only when something changed |
| `oled.*` | OLED probe at 100 kHz with retries; re-check every 3 s, re-init after a blip |
| `ui.*` | Draws the screens, popups and overlays (reads state, changes nothing) |
| `face.*` | Mochi: moods, states, blinking, gaze, animations |
| `app.*` | Behaviour: screens, notifications, sleep, LEDs, state pushes, link switching, power-off |
| `protocol.*` | JSON messages with the app (ArduinoJson 7) |
| `link.*`, `link_ble.cpp`, `link_wifi.cpp` | One interface over both radios, plus the inbox queue |
| `buttons.*`, `leds.*`, `buzzer.*` | Debounced buttons, LED patterns, non-blocking melodies (LEDC) |
| `battery.*`, `power.*` | Battery reading and deep-sleep power switch (compiled out in the USB build) |
| `cli.*` | Serial command line |
| `logic/` | `framing.h` (BLE line framing), `text.h` (UTF-8 → ASCII, word wrap), `notif_store.h`, `tz.h`, `battery_curve.h` |

### Pinned versions

Everything is pinned in `platformio.ini` so builds are identical everywhere:

| Component | Version |
|---|---|
| Platform | pioarduino 55.03.36 (Arduino-ESP32 3.3.6) |
| U8g2 | 2.36.19 |
| ArduinoJson | 7.4.3 |
| NimBLE-Arduino | 2.5.1 |
| arduinoWebSockets | 2.7.2 |
| WiFiManager | 2.0.17 |

### Lessons learned: don't undo these

| Rule | Why |
|---|---|
| Stay on **pioarduino / Arduino core 3.x** | Core 2.0.x couldn't drive I2C on the Super Mini; the OLED stayed black. |
| Write for **NimBLE 2.x** and call `setCallbacks(&cb, false)` | 1.x and 2.x have different callback signatures. With `true`, NimBLE deletes static callback objects, which crashed on the Bluetooth → WiFi switch. |
| Keep **WiFi TX power at 8.5 dBm** | At full power, the Super Mini's antenna distorts the signal, and phones couldn't see the setup network. |
| Keep **WiFi modem sleep off** | With it on, mDNS/FIND and `deskbuddy-c3.local` were unreliable. |
| Keep the **slow, retried OLED probe** and the hot-plug check | Probing once at 400 kHz right after power-on missed the OLED. |
| Never read GPIO0 unless the battery build is selected, and require plausible readings first | A floating GPIO0 read as "battery empty" and switched the board off. |
| Keep `monitor_rts = 0` / `monitor_dtr = 0` | DTR/RTS toggling resets the C3's native USB serial. |
| Flash release images **around NVS** unless erasing | The merged image's padding covers NVS and wiped the saved WiFi network. |

### Tests

```bash
sh firmware/test/host/run_tests.sh
```

This runs 537 checks of the pure logic in `src/logic` on a PC with g++: framing, text folding and wrapping, the notification store, time zones and the battery curve. On Windows, run it in Git Bash or WSL.

## The `deskbuddy` tool

### Setting up

```bash
cd tool
python -m venv .venv
# Windows: .venv\Scripts\activate    Linux: source .venv/bin/activate
pip install -e ".[dev]"
```

### Checks (the same as CI)

```bash
ruff check . && ruff format --check .
mypy src
pytest --cov
```

The suite has 257 tests and about 94 % coverage. It uses fakes for serial ports, subprocesses and HTTP, so it needs no board or network.

### How it works

- **Flashing:** `python -m esptool` runs as a subprocess, with the right command spelling for esptool 4 or 5. Progress is parsed from esptool's output. Images are written at 921600 baud, falling back to 460800 and 115200. When the chip doesn't sync, the BOOT/RESET hint is shown and the tool retries.
- **Release images:** each is one merged binary (bootloader, partitions, boot_app0, app) meant for `0x0`. Unless `--erase` is given, it's written as two pieces that skip NVS (`0x9000–0xE000`), so settings and WiFi survive.
- **Downloads:** from the GitHub Releases API. They must match `SHA256SUMS` (and GitHub's own digest, when present), and are cached in `~/.deskbuddy/firmware`. Source archives are extracted with path checks.
- **Serial:** ports are opened with DTR/RTS off. The monitor is a reconnecting state machine, so it survives resets.
- **Building:** a private PlatformIO (its own venv and core folder) is used. `GITHUB_TOKEN` is kept away from build processes, and `MSYSTEM` is removed so pioarduino's tools run from Git Bash too.
- **The CLI and the UI** are thin layers over the same `installer.py` / `serial_io.py` / `monitor.py`.

## CI and releases

**`ci.yml`** (every push and pull request):
- builds both firmware envs;
- runs the host tests;
- runs ruff, mypy and pytest for the tool on Ubuntu and Windows, with Python 3.9 and 3.12;
- checks the Android app. It's skipped while `app/` has no Gradle wrapper.

**`release.yml`** (on a `vX.Y.Z` tag):
1. Checks that the tag matches `FW_VERSION`.
2. Builds both envs with `scripts/merge_firmware.py`.
3. Takes the release notes from `CHANGELOG.md`.
4. Publishes the GitHub Release with the images, `SHA256SUMS` and `manifest.json`.

### Cutting a release

1. Change the firmware, and bump `FW_VERSION` in `firmware/src/config.h` (e.g. `"c3-2.1.0"`).
2. Add a `## [2.1.0] - YYYY-MM-DD` section at the top of `CHANGELOG.md`. It becomes the release notes.
3. If the tool changed, bump `__version__` in `tool/src/deskbuddy/__init__.py`.
4. Commit, push to `main`, and wait for CI to go green.
5. Tag and push:
   ```bash
   git tag v2.1.0
   git push origin v2.1.0
   ```
6. When the release workflow finishes, check that `deskbuddy versions` lists it and `deskbuddy flash` installs it.

`manifest.json` lists, for each build, `env`, `build`, `file`, `sha256`, `size`, `chip` and `offset`, plus the release `version` and `tool_min_version`.

## Known limitations / ideas

- `deskbuddy cmd` treats silent commands (`face`, `screen`, `press`) as "no reply". A firmware `ok` reply, or a list of silent commands, would fix that.
- OTA flashing isn't in the tool yet; use `pio run -e ota -t upload`.
- The tool isn't on PyPI yet; install it from GitHub.
- The Android app isn't built in CI. Add a Gradle wrapper (`gradle wrapper` in `app/`) to enable it.
- Linux has only been tested in CI, not with a real board.
- Hardening: protect `v*` tags, add a protected environment for the release job, and pin GitHub Actions to commit SHAs.
